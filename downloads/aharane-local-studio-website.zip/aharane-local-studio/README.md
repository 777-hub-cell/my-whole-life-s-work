Aharane Local Studio — website and server source
================================================

Source repository: 777-hub-cell/my-whole-life-s-work
Source branch: mscc-azure
Source commit: 07dba980b85e2cd62339227fdd3f4fddbe28b3fb

This archive contains the editable Aharane Local Studio PWA front end and the Aharane server/runtime files that provide its API.

Front end: control-centre/index.html, styles.css, app.js, sw.js, manifest.webmanifest, icon.svg
Server: src/index.js, src/policy.js, src/update-manager.js, package.json, .env.example

Excluded: real .env values, admin tokens, passwords, cookies, WhatsApp authentication/session folders, databases, uploads, backups, logs, SSH keys, certificates, deployment secrets, node_modules and Git history.

Local development: use Node.js 24 or newer; run npm install; copy .env.example to a private .env file; set a random AHARANE_ADMIN_TOKEN of at least 32 characters and your own data directory/allowlist; then run node --env-file=.env src/index.js. Never commit the real .env file.

The PWA is mounted at /aharane/studio/ and uses same-origin /aharane/api/* and /aharane/ws. The server binds to loopback by default; do not expose port 8790 directly to the internet. This is a source bundle for editing/development, not a production restore package. Review configuration and security before deploying. It does not change the live Azure site or NIGHT/MSCC.
