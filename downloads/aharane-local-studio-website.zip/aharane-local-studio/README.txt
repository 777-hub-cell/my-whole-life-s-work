Aharane Local Studio — website source
=====================================

Source repository: 777-hub-cell/my-whole-life-s-work
Source branch: mscc-azure
Source commit: 07dba980b85e2cd62339227fdd3f4fddbe28b3fb

Included editable PWA front-end files:
- index.html
- styles.css
- app.js
- sw.js
- manifest.webmanifest
- icon.svg

This is the website/front-end source for Aharane Local Studio. It is not a
complete server deployment. The Aharane API, WhatsApp runtime, authentication
service, persistent data and environment configuration remain on the server
and are intentionally not included.

No .env file, admin token, password, session cookie, WhatsApp auth data, SSH
key, certificate, database or runtime user data is included.

Keep the manifest start_url/scope and service-worker paths aligned with the
/aharane/studio/ deployment path. Remote controls require the existing
same-origin /aharane/api/* and /aharane/ws backend.

This archive is a clean source snapshot from the production source branch.
It does not change the live Azure website.
