import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
const read = path => readFile(new URL(path, import.meta.url), 'utf8')

test('Aharane serves the Local Studio PWA from its private listener', async () => {
 const s=await read('../src/index.js')
 for(const marker of ["app.use('/studio',","new URL('../control-centre/',import.meta.url)","app.use('/studio/api'","app.get('/api/status', requireAdmin","app.get('/api/auth/status'","app.post('/api/auth/setup'","app.post('/api/auth/login'","app.post('/api/auth/logout'","HOST !== '127.0.0.1'"])assert.ok(s.includes(marker),marker)
})

test('AI Reply shares Aharane Groq ENV, requires authentication and never accepts chat history', async () => {
 const runtime = await read('../src/index.js')
 const service = await read('../src/ai-reply.js')
 assert.ok(runtime.includes("import { createAiReplyService } from './ai-reply.js'"))
 assert.ok(runtime.includes("createAiReplyService({ env: process.env })"))
 assert.ok(runtime.includes("env: [...envView(studioSettings), ...aiReplyService.environmentRows()]"))
 const availabilityStart = runtime.indexOf("app.get('/api/ai/availability'")
 const replyStart = runtime.indexOf("app.post('/api/ai/reply'")
 const settingsStart = runtime.indexOf("app.get('/api/settings'", replyStart)
 const availability = runtime.slice(availabilityStart, replyStart)
 const reply = runtime.slice(replyStart, settingsStart)
 assert.ok(availability.includes('requireAdmin'))
 assert.ok(reply.includes('requireAdmin'))
 assert.ok(reply.includes('aiReplyService.generate'))
 for (const field of ['message', 'quotedMessage', 'tone', 'instruction']) assert.ok(reply.includes('req.body?.' + field))
 assert.ok(!reply.includes('chatStore'))
 assert.ok(!reply.includes('searchMessages'))
 assert.ok(service.includes('GROQ_API_KEY'))
 assert.ok(service.includes('GROQ_SMART_MODELS'))
 assert.ok(service.includes('explicitlyQuotedMessage'))
 assert.ok(service.includes('Never infer or retrieve previous chat messages'))
 assert.ok(service.includes("secret: true"))
})

test('owner password is salted and sessions are long-lived HttpOnly cookies', async () => {
 const s=await read('../src/index.js')
 for(const marker of ["scryptAsync","randomBytes(16)","ADMIN_SESSION_COOKIE = 'aharane_admin_session'","30 * 24 * 60 * 60","HttpOnly; Secure; SameSite=Strict","Path=/aharane/","ADMIN_AUTH_FILE","ADMIN_SETUP_CODE_FILE","timingSafeEqual(actual, expected)"])assert.ok(s.includes(marker),marker)
 assert.ok(!s.includes("ADMIN_SESSION_SECONDS=12*60*60"))
})

test('password change rotates the session key and logout clears the scoped cookie', async () => {
 const s=await read('../src/index.js')
 assert.ok(s.includes("app.post('/api/auth/change-password'"))
 assert.ok(s.includes('sessionKey: randomBytes(32)'))
 assert.ok(s.includes("Max-Age=0"))
 assert.ok(s.includes("writeJsonAtomic(ADMIN_AUTH_FILE, updated)"))
})

test('HttpOnly session cookies authenticate same-origin GETs and WebSocket upgrades', async () => {
 const s=await read('../src/index.js')
 assert.ok(s.includes("adminSessionMatches(requestCookie(req, ADMIN_SESSION_COOKIE), auth)"))
 assert.ok(s.includes("sameOriginRequest(req) && adminSessionMatches(cookie, auth)"))
 assert.ok(s.includes("async (req, transport, head)"))
})


test('both accounts pair from their saved configuration number without a duplicate phone input', async () => {
 const s=await read('../src/index.js')
 const start=s.indexOf("app.post('/api/accounts/:accountId/pair-code'")
 const end=s.indexOf("app.get('/api/accounts/:accountId/qr'",start)
 const route=s.slice(start,end)
 assert.ok(route.includes("accountId === 'private' ? ownerConfig.privateOwnerNumber : ownerConfig.publicBotNumber"))
 assert.ok(!route.includes("session.registered || session.state === 'connected'"), 'A previously linked account remains eligible for safe replacement pairing.')
 assert.ok(route.includes('accountRuntime.requestPairingCode(accountId, phoneNumber)'))
 assert.ok(!route.includes('req.body?.phoneNumber'))
 assert.ok(!route.includes('ownerConfig.publicOwnerNumber'))
})

test('QR reads are passive and a QR socket starts only after an explicit POST request', async () => {
 const s=await read('../src/index.js')
 const start=s.indexOf("app.get('/api/accounts/:accountId/qr'")
 const end=s.indexOf("app.post('/api/accounts/:accountId/reconnect'",start)
 const routes=s.slice(start,end)
 const getRoute=routes.slice(0,routes.indexOf("app.post('/api/accounts/:accountId/qr'"))
 const postRoute=routes.slice(routes.indexOf("app.post('/api/accounts/:accountId/qr'"))
 assert.ok(!getRoute.includes('accountRuntime.start('), 'GET must never start a pairing socket.')
 assert.ok(!getRoute.includes('accountRuntime.startPairing('), 'GET must remain a passive read.')
 assert.ok(postRoute.includes('await accountRuntime.startPairing(accountId)'), 'Only explicit POST starts an isolated QR candidate.')
 assert.ok(getRoute.includes('accountRuntime.pairingQr(accountId)'))
 assert.ok(getRoute.includes('pairingSucceeded'))
 assert.ok(getRoute.includes('pairingError'))
})

test('the backend exposes protected full-history chat search and browser file downloads', async () => {
 const s=await read('../src/index.js')
 assert.ok(s.includes("app.get('/api/chats/:accountId/search'"))
 assert.ok(s.includes('chatStore.searchMessages(accountId'))
 assert.ok(s.includes("app.get('/api/files/download'"))
 assert.ok(s.includes("app.post('/api/files/export-selection'"))
 assert.ok(s.includes("Content-Disposition', `attachment; filename*=UTF-8''"))
})

test('Files root enumerates the deployed release and exposes only allowlisted source entries', async () => {
 const s=await read('../src/index.js')
 const start=s.indexOf("async function listSourceFiles(relativePath = '')")
 const end=s.indexOf("\nasync function ensureManualEditBackup()",start)
 const fn=s.slice(start,end)
 assert.ok(fn.includes('const base = await sourceWorkspaceDirectory()'))
 assert.ok(fn.includes('readdir(base, { withFileTypes: true })'))
 assert.ok(fn.includes('SOURCE_DIRS.has(row.name)'))
 assert.ok(fn.includes('SOURCE_ROOT_FILES.has(row.name)'))
 assert.ok(fn.includes('row.isSymbolicLink()'))
})

test('source ZIP export is protected and only includes allowlisted source files', async () => {
 const s=await read('../src/index.js')
 const module=await read('../src/source-export.js')
 const route=s.slice(s.indexOf("app.get('/api/files/export'"),s.indexOf("app.get('/api/files/tree'"))
 assert.ok(route.includes('requireAdmin'))
 assert.ok(route.includes('listSourceFiles(directory)'))
 assert.ok(route.includes('safeSourceTarget(path)'))
 assert.ok(route.includes("Content-Type', 'application/zip'"))
 assert.ok(route.includes(String.raw`Content-Disposition', 'attachment; filename="aharane-source.zip"'`))
 assert.ok(route.includes('createSourceZip(files)'))
 assert.ok(module.includes('0x04034b50'))
 assert.ok(module.includes('0x02014b50'))
 assert.ok(module.includes('0x06054b50'))
})

test('the supplied Studio preview uses protected same-origin APIs', async () => {
 const html=await read('../control-centre/index.html')
 const bridge=await read('../control-centre/production-bridge.js')
 assert.ok(html.includes('src="/aharane/studio/app.js"'))
 assert.ok(html.includes('src="/aharane/studio/production-bridge.js"'))
 assert.ok(bridge.includes("const API='/aharane/api'"))
 assert.ok(bridge.includes("credentials:'same-origin'"))
 for(const marker of ["apiP('auth/status'","apiP('auth/login'","apiP('auth/setup'","apiP('owners'","apiP('env'","apiP('storage'","apiP('activity","apiP('files/tree","apiP('files/content'","apiP('update/upload/start'"])assert.ok(bridge.includes(marker),marker)
 assert.ok(!bridge.includes('vercel.app'))
})

test('the production home, accounts, files, ENV and chats use real server data', async () => {
 const bridge=await read('../control-centre/production-bridge.js')
 const runtime=await read('../src/index.js')
 for(const marker of ["apiP('studio/snapshot'","apiP('metrics'","apiP('accounts/'+id+'/qr'","apiP('chats/'+account","apiP('files/preview?item='","apiP('env'","apiP('storage'","apiP('activity?limit="])assert.ok(bridge.includes(marker),marker)
 for(const marker of ["app.get('/api/chats/:accountId'","app.get('/api/chats/:accountId/:jid/messages'","app.post('/api/chats/:accountId/:jid/send'","app.post('/api/chats/:accountId/:jid/media'","app.get('/api/storage'","app.get('/api/activity'"])assert.ok(runtime.includes(marker),marker)
 assert.ok(runtime.includes("!authorizedChat(accountId, media.jid) || !isChatVisible(studioSettings[accountId], media.jid)"), 'Media URLs enforce the same account visibility filter as messages')
})

test('the preview keeps its original mobile file-manager and editor interactions', async () => {
 const html=await read('../control-centre/index.html')
 const app=await read('../control-centre/app.js')
 const css=await read('../control-centre/styles.css')
 const bridge=await read('../control-centre/production-bridge.js')
 assert.ok(html.includes('<main class="app">')||html.includes('class="app"'))
 assert.ok(app.includes('function filesV()'))
 assert.ok(app.includes('function menu('))
 assert.ok(app.includes('function editorOld()'))
 assert.ok(app.includes('placeholder="Search files and folders"'))
 assert.ok(css.includes('.row{'))
 assert.ok(css.includes('.pop{'))
 assert.ok(css.includes('.editor{'))
 for(const marker of ["apiP('files/tree","apiP('files/preview","apiP('files/content'","apiP('files/rename'","apiP('files/move'","apiP('files/delete'","apiP('files/apply'"])assert.ok(bridge.includes(marker),marker)
})

test('the app source editor works on-device and can safely reset its overrides', async () => {
 const html=await read('../control-centre/index.html')
 const bridge=await read('../control-centre/production-bridge.js')
 const worker=await read('../control-centre/sw.js')
 const recovery=await read('../control-centre/recover.html')
 for(const file of ['index.html','styles.css','app.js','production-bridge.js','manifest.webmanifest'])assert.ok(bridge.includes(file))
 for(const marker of ["id=\"open-local-source\"","indexedDB.open('aharane-local-studio',2)","objectStore('appOverrides').put","objectStore('appOverrides').clear","function openAppSourceP","function saveAppSourceP","function resetAppSourceP"])assert.ok(bridge.includes(marker),marker)
 assert.ok(worker.includes('aharane-local-studio-shell-v14'))
 assert.ok(worker.includes('SOURCE_PATHS'))
 assert.ok(worker.includes("['/aharane/studio/production-bridge.js','production-bridge.js']"))
 assert.ok(worker.includes("u.pathname.startsWith('/aharane/api/')"))
 assert.ok(recovery.includes("objectStore('appOverrides').clear()"))
 assert.ok(html.includes('href="/aharane/studio/manifest.webmanifest"'))
})

test('Files menus remain compact floating overlays and staged changes require explicit apply', async () => {
 const app=await read('../control-centre/app.js')
 const bridge=await read('../control-centre/production-bridge.js')
 const css=await read('../control-centre/styles.css')
 assert.ok(app.includes('function menu('))
 assert.ok(app.includes("m.className='pop'"))
 assert.ok(css.includes('.pop{'))
 assert.ok(bridge.includes('function fileMenuP'))
 assert.ok(bridge.includes('files/apply'))
 assert.ok(bridge.includes('Apply staged source changes and restart Aharane?'))
})

test('browser navigation remains driven by the supplied five-tab preview', async () => {
 const app=await read('../control-centre/app.js')
 for(const marker of ["const T={home:'Home',files:'Files',env:'ENV',chats:'Chats',more:'More'}","function nav()","function render()","function go(t)"])assert.ok(app.includes(marker),marker)
})

test('WebSocket stays protected and exposes only status and ping actions', async () => {
 const s=await read('../src/index.js')
 for(const marker of ["server.on('upgrade'","pathname !== '/ws'","adminSessionMatches(cookie, auth)","message?.type === 'ping'","message?.type === 'status.get'","Unsupported message type"])assert.ok(s.includes(marker),marker)
})

test('the source editor view and account identity settings are reachable', async () => {
 const bridge=await read('../control-centre/production-bridge.js')
 assert.ok(bridge.includes("if(S.sub==='source')return appSourceViewP()"))
 assert.ok(bridge.includes("onclick=\"openAcc()\""))
 assert.ok(bridge.includes("const localSource=Q('#offline-open-source')"))
})


test('source path validation imports the shared ZIP path normalizer', async () => {
 const runtime = await read('../src/index.js')
 const updates = await read('../src/update-manager.js')
 assert.ok(runtime.includes("MAX_ARCHIVE_BYTES, normalizeUpdatePath } from './update-manager.js'"), 'The source path helper must be imported from update-manager.js.')
 assert.ok(updates.includes('export function normalizeUpdatePath'))
 assert.ok(runtime.includes('const normalized = normalizeUpdatePath(relativePath)'))
})


test('phone-number pairing uses a canonical browser identity for WhatsApp companion linking', async () => {
 const s = await read('../src/index.js')
 assert.ok(s.includes("browser: Browsers.macOS('Chrome')"), 'Pairing code companion display must use a recognized Chrome/Mac OS identity, not the custom Aharane label.')
})


test('Files Manager exposes the real Control Centre website source as editable files', async () => {
 const s=await read('../src/index.js')
 assert.ok(s.includes("'control-centre'"), 'The deployed website source directory must be in the source workspace allowlist.')
 assert.ok(s.includes("'.webmanifest'"), 'The PWA manifest must be editable.')
 assert.ok(s.includes("'.svg'"), 'The website icon source must be editable.')
 assert.ok(s.includes("new URL('../control-centre/',import.meta.url)"), 'The Files source and served Studio must resolve from the same project directory.')
})

test('new and existing file writes are checked against their on-disk contents before success', async () => {
 const s=await read('../src/index.js')
 const create=s.slice(s.indexOf("app.post('/api/files'"),s.indexOf("app.put('/api/files/content'"))
 const update=s.slice(s.indexOf("app.put('/api/files/content'"),s.indexOf("app.post('/api/files/rename'"))
 assert.ok(create.includes("const savedContent = await readFile(target.full, 'utf8')"))
 assert.ok(create.includes('if (savedContent !== content)'))
 assert.ok(update.includes("const savedContent = await readFile(target.full, 'utf8')"))
 assert.ok(update.includes('if (savedContent !== content)'))
})

test('native media uploads use stable idempotency keys and an encrypted local outbox', async () => {
 const runtime=await read('../src/index.js')
 const store=await read('../src/chat-store.js')
 const client=await read('../android/app/src/main/kotlin/com/aharane/studio/core/network/AharaneApiClient.kt')
 const local=await read('../android/app/src/main/kotlin/com/aharane/studio/core/storage/LocalChatRepository.kt')
 assert.ok(runtime.includes("req.get('x-client-message-id')"))
 assert.ok(runtime.includes('chatStore.beginIdempotentMediaSend'))
 assert.ok(runtime.includes('chatStore.completeIdempotentSend(accountId, clientMessageId, messageId)'))
 assert.ok(runtime.includes('This attachment send already started'))
 assert.ok(store.includes('async function beginIdempotentMediaSend'))
 assert.ok(client.includes('"X-Client-Message-Id"'))
 assert.ok(local.includes('ChatOutgoingMediaRow'))
 assert.ok(local.includes('EncryptedMediaRecord'))
})

test('poll voting uses the pinned Baileys encrypted poll-vote helper and server routes', async () => {
 const runtime=await read('../src/index.js')
 const store=await read('../src/chat-store.js')
 const polls=await read('../src/chat-polls.js')
 assert.ok(runtime.includes("'/api/chats/:accountId/:jid/polls'"))
 assert.ok(runtime.includes("'/api/chats/:accountId/:jid/:messageId/poll-vote'"))
 assert.ok(runtime.includes('applyIncomingPollVote'))
 assert.ok(runtime.includes('decryptIncomingPollVote'))
 assert.ok(store.includes('async function applyPollVote'))
 assert.ok(store.includes('pollVotesByActor'))
 assert.ok(polls.includes('proto.Message.PollVoteMessage.encode'))
 assert.ok(polls.includes('decryptPollVote(vote'))
})

test('Web Chat supports persistent chat preferences, per-conversation search, quoted replies and message actions', async () => {
 const runtime=await read('../src/index.js')
 const store=await read('../src/chat-store.js')
 const bridge=await read('../control-centre/production-bridge.js')
 const app=await read('../control-centre/app.js')
 assert.ok(!runtime.includes('downloadMedia: (msg, socket) => downloadMediaMessage'), 'Incoming message handlers must not download media on receipt.')
 for(const marker of [
  "app.put('/api/chats/:accountId/preferences'",
  "app.get('/api/chats/:accountId/:jid/search'",
  "app.post('/api/chats/:accountId/:jid/media/:messageId/download'",
  "app.post('/api/chats/:accountId/:jid/reaction'",
  "app.post('/api/chats/:accountId/:jid/forward'",
  "app.post('/api/chats/:accountId/:jid/delete'",
  "quoted: quoted.sourceMessage",
  "ptt: req.get('x-voice-note') === 'true'"
 ]) assert.ok(runtime.includes(marker),marker)
 for(const marker of ['downloadMessageMedia','applyReaction','deleteMessage','sourceMessage','reactions'])assert.ok(store.includes(marker),marker)
 for(const marker of ['chatPreferences','chat-searchbar','openMessageMenuP','downloadChatMediaP','toggleChatPreferenceP','switchChats=switchChatsP','X-Voice-Note'])assert.ok(bridge.includes(marker),marker)
 for(const marker of ['rec-waveform','MediaRecorder','analyser.getByteFrequencyData','openMessageMenuP','data-chat-pref','reaction-chips'])assert.ok(app.includes(marker),marker)
})


test('rate limits use only the trusted loopback reverse proxy and command cooldown is command-only', async () => {
 const source=await read('../src/index.js')
 assert.ok(source.includes("app.set('trust proxy', 'loopback')"))
 const handler=source.slice(source.indexOf('async function handleMessages'),source.indexOf("publicCommandRegistry = await loadCommandRegistry"))
 assert.ok(handler.indexOf('parseCommand(text, prefix)')<handler.indexOf('allowCommand(sessionId +'))
 assert.ok(handler.includes('!registry?.commands?.has(parsedCommand.name)'))
})

test('legacy public pairing cannot override the configured Public bot number', async () => {
 const source=await read('../src/index.js')
 const start=source.indexOf("app.post('/api/pair-code'")
 const end=source.indexOf("app.get('/api/update/status'",start)
 const route=source.slice(start,end)
 assert.ok(route.includes('phoneNumber !== ownerConfig.publicBotNumber'))
 assert.ok(route.includes("requestPairingCode('public', ownerConfig.publicBotNumber)"))
})

test('deployment locks are shared by source mutations, manual Apply, ZIP and Git installer', async () => {
 const runtime=await read('../src/index.js')
 const installer=await read('../install-azure.sh')
 assert.ok(runtime.includes("const DEPLOY_LOCK_DIR = join(DATA_DIR, 'deploy-lock')"))
 assert.ok(runtime.includes("acquireDeployLock('source-mutation')"))
 assert.ok(runtime.includes("req.deployLockAcquired"))
 assert.ok(runtime.includes("setDeployLockSource('manual-files')"))
 assert.ok(runtime.includes("setDeployLockSource('zip-update')"))
 const start=installer.indexOf("cat > /usr/local/lib/aharane/verify-update.mjs <<'VERIFY'")
 const end=installer.indexOf("\nVERIFY",start)
 const verifier=installer.slice(start,end)
 assert.ok(verifier.includes("owner?.source === 'git'"))
 assert.ok(verifier.includes("rm('/var/lib/aharane/deploy-lock'"))
 assert.ok(installer.includes('mkdir "$LOCK_DIR"'))
 assert.ok(installer.includes('"$BASHPID" "$SOURCE_SHA"'))
})

test('bulk delete stages every item and commits one journal operation before cleanup', async () => {
 const source=await read('../src/index.js')
 const start=source.indexOf("app.post('/api/files/delete'")
 const end=source.indexOf("app.post('/api/files/apply'",start)
 const route=source.slice(start,end)
 assert.ok(route.includes('const stagedTombstones = []'))
 assert.ok(route.includes('await recordManualEdits(stagedTombstones.map'))
 assert.ok(route.includes('for (const item of [...stagedTombstones].reverse())'))
 assert.ok(route.includes('cleanupPending'))
})

test('manual dependency manifest changes are directed to the ZIP update installer', async () => {
 const source=await read('../src/index.js')
 assert.ok(source.includes("normalized === 'package.json' || normalized === 'package-lock.json'"))
 assert.ok(source.includes('must be deployed as a validated ZIP update'))
})


test('permanent installer bearer token is revoked after the owner creates a Studio password', async () => {
 const source=await read('../src/index.js')
 assert.ok(source.includes('const adminBearer = !auth?.passwordHash && tokenMatches(bearer)'))
 assert.ok(source.includes('const ok = (!auth?.passwordHash && tokenMatches(bearer)) || adminSessionMatches(bearer, auth)'))
 assert.ok(source.includes('sessionKey: randomBytes(32)'))
})


test('WhatsApp transport exposes a versioned capability contract and no Status API', async () => {
 const runtime=await read('../src/index.js')
 const contract=await read('../src/whatsapp-contract.js')
 const discovery=await read('../src/whatsapp-discovery.js')
 assert.ok(runtime.includes("app.get('/api/whatsapp/:accountId/capabilities'"))
 assert.ok(runtime.includes('WHATSAPP_TRANSPORT_CONTRACT_VERSION'))
 assert.ok(runtime.includes('inspectWhatsAppCapabilities'))
 assert.ok(runtime.includes("app.get('/api/whatsapp/:accountId/channels'"))
 assert.equal(runtime.includes("app.get('/api/whatsapp/:accountId/statuses'"), false)
 assert.equal(runtime.includes("app.get('/api/whatsapp/:accountId/statuses/:sender/:messageId/media'"), false)
 assert.doesNotMatch(runtime, /whatsappDiscovery\.(recordStatus|listStatuses|getStatusMedia)/)
 assert.doesNotMatch(discovery, /status@broadcast|recordStatus|listStatuses|getStatusMedia/i)
 assert.ok(contract.includes('WHATSAPP_TRANSPORT_CONTRACT_VERSION = 1'))
})
