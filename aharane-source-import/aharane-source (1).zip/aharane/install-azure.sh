#!/usr/bin/env bash
set -euo pipefail

# Invoked as root by the separately gated Aharane deployment workflow.
SOURCE_SHA="${1:-}"
ARCHIVE="${2:-}"
[[ "$SOURCE_SHA" =~ ^[0-9a-f]{40}$ ]] || { echo "A full lowercase source SHA is required." >&2; exit 2; }
[[ -f "$ARCHIVE" ]] || { echo "Aharane source archive is missing." >&2; exit 2; }
[[ "$(id -u)" -eq 0 ]] || { echo "Run this installer as root." >&2; exit 2; }
command -v systemctl >/dev/null
command -v node >/dev/null
command -v npm >/dev/null
command -v curl >/dev/null
command -v openssl >/dev/null
node -e 'if (Number(process.versions.node.split(".")[0]) < 24) process.exit(1)' || {
  echo "Aharane requires Node.js 24 or newer." >&2
  exit 2
}

SERVICE_USER="aharane"
BASE="/opt/aharane"
STATE="/var/lib/aharane"
ENV_FILE="/etc/aharane.env"
SERVICE_FILE="/etc/systemd/system/aharane.service"
RELEASE="$BASE/releases/$SOURCE_SHA-$(date -u +%Y%m%dT%H%M%SZ)-$$"
STAGING="$(mktemp -d /tmp/aharane-install.XXXXXXXX)"
PREVIOUS_RELEASE="$(readlink -f "$BASE/current" 2>/dev/null || true)"
SERVICE_BACKUP="$(mktemp /tmp/aharane-service-backup.XXXXXXXX)"
LOCK_DIR="$STATE/deploy-lock"
LOCK_ACQUIRED=0
SERVICE_EXISTED=0
SWITCHED=0
SUCCESS=0
ROLLBACK_OK=0

rollback() {
  local failed=0
  set +e
  if [[ -n "$PREVIOUS_RELEASE" && -d "$PREVIOUS_RELEASE" ]]; then
    local rollback_link="$BASE/.current-rollback-$$"
    ln -s "$PREVIOUS_RELEASE" "$rollback_link" && mv -Tf "$rollback_link" "$BASE/current" || failed=1
  else
    rm -f "$BASE/current" || failed=1
  fi
  if [[ "$SERVICE_EXISTED" -eq 1 ]]; then
    cp -p "$SERVICE_BACKUP" "$SERVICE_FILE" || failed=1
  else
    rm -f "$SERVICE_FILE" || failed=1
  fi
  systemctl daemon-reload || failed=1
  if [[ -n "$PREVIOUS_RELEASE" && -d "$PREVIOUS_RELEASE" ]]; then
    systemctl restart aharane.service || failed=1
  else
    systemctl disable --now aharane.service >/dev/null 2>&1 || true
  fi
  set -e
  if [[ "$failed" -eq 0 ]]; then ROLLBACK_OK=1; fi
  return 0
}

cleanup() {
  rm -rf "$STAGING"
  if [[ "$SUCCESS" -eq 1 || "$ROLLBACK_OK" -eq 1 || "$SWITCHED" -eq 0 ]]; then
    rm -f "$SERVICE_BACKUP"
  else
    echo "Preserving the prior service unit backup for manual recovery: $SERVICE_BACKUP" >&2
  fi
  if [[ "$SUCCESS" -ne 1 && ( "$SWITCHED" -eq 0 || "$ROLLBACK_OK" -eq 1 ) ]]; then
    rm -rf "$RELEASE"
  elif [[ "$SUCCESS" -ne 1 ]]; then
    echo "Preserving failed Aharane release for manual recovery: $RELEASE" >&2
  fi
}

finish() {
  local status=$?
  trap - EXIT
  if [[ "$status" -ne 0 && "$SWITCHED" -eq 1 ]]; then
    echo "Aharane install failed; rolling back only Aharane resources." >&2
    rollback
    if [[ "$ROLLBACK_OK" -ne 1 ]]; then
      echo "Aharane rollback was incomplete; preserving the failed release for recovery." >&2
    fi
  fi
  cleanup
  if [[ "$LOCK_ACQUIRED" -eq 1 ]]; then rm -rf "$LOCK_DIR"; fi
  exit "$status"
}
trap finish EXIT

if [[ -e "$SERVICE_FILE" ]] && ! grep -Fq 'Description=Aharane independent WhatsApp bot' "$SERVICE_FILE"; then
  echo "An unrelated aharane.service already exists; refusing to overwrite it." >&2
  exit 2
fi
if [[ -f "$SERVICE_FILE" ]]; then
  cp -p "$SERVICE_FILE" "$SERVICE_BACKUP"
  SERVICE_EXISTED=1
fi

tar -xzf "$ARCHIVE" --strip-components=1 -C "$STAGING"
[[ -f "$STAGING/package.json" && -f "$STAGING/src/index.js" && -f "$STAGING/.env.example" ]] || {
  echo "Archive does not contain the expected Aharane application." >&2
  exit 2
}

if ! id "$SERVICE_USER" >/dev/null 2>&1; then
  useradd --system --home-dir "$STATE" --create-home --shell /usr/sbin/nologin "$SERVICE_USER"
fi
install -d -o "$SERVICE_USER" -g "$SERVICE_USER" -m 0750 "$BASE" "$BASE/releases" "$STATE" "$STATE/whatsapp-auth"
install -d -o "$SERVICE_USER" -g "$SERVICE_USER" -m 0750 "$STATE/data" "$STATE/updates" "$STATE/updates/uploads"
if ! mkdir "$LOCK_DIR"; then
  echo "Another Aharane deployment is already in progress." >&2
  exit 2
fi
LOCK_ACQUIRED=1
chown "$SERVICE_USER:$SERVICE_USER" "$LOCK_DIR"
printf '{"source":"git","pid":%s,"sha":"%s","startedAt":"%s"}' "$BASHPID" "$SOURCE_SHA" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$LOCK_DIR/owner.json"
chown "$SERVICE_USER:$SERVICE_USER" "$LOCK_DIR/owner.json"
chmod 0600 "$LOCK_DIR/owner.json"
install -d -o root -g root -m 0755 /usr/local/lib/aharane
cat > /usr/local/lib/aharane/verify-update.mjs <<'VERIFY'
import { readFile, rename, rm, symlink, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { randomUUID } from 'node:crypto'

const root = '/opt/aharane'
const current = path.join(root, 'current')
const releases = path.join(root, 'releases')
const stateFile = '/var/lib/aharane/updates/state.json'

async function readState() {
  try { return JSON.parse(await readFile(stateFile, 'utf8')) }
  catch { return null }
}
async function writeState(value) {
  const temporary = stateFile + '.verify-' + randomUUID()
  await writeFile(temporary, JSON.stringify(value, null, 2), { mode: 0o600, flag: 'wx' })
  await rename(temporary, stateFile)
}
async function pause(ms) {
  await new Promise(resolve => setTimeout(resolve, ms))
}

const ownerText = await readFile('/var/lib/aharane/deploy-lock/owner.json', 'utf8').catch(() => '')
let owner = null
try { owner = JSON.parse(ownerText) } catch {}
if (owner?.source === 'git') {
  const pid = Number(owner.pid)
  if (Number.isInteger(pid) && pid > 0) {
    try { process.kill(pid, 0); process.exit(0) }
    catch (error) { if (error?.code === 'EPERM') process.exit(0) }
  }
  await rm('/var/lib/aharane/deploy-lock', { recursive: true, force: true }).catch(() => {})
  process.exit(0)
}

const state = await readState()
if (!state || state.status !== 'awaiting-healthcheck') {
  await rm('/var/lib/aharane/deploy-lock', { recursive: true, force: true }).catch(() => {})
  process.exit(0)
}

const previous = path.resolve(String(state.previousRelease || ''))
if (!previous.startsWith(releases + path.sep)) {
  await writeState({ ...state, status: 'rollback_failed', message: 'Previous release path was invalid.', finishedAt: new Date().toISOString() })
  await rm('/var/lib/aharane/deploy-lock', { recursive: true, force: true }).catch(() => {})
  process.exit(1)
}

let healthy = false
for (let attempt = 0; attempt < 25; attempt += 1) {
  try {
    const response = await fetch('http://127.0.0.1:8790/healthz', { signal: AbortSignal.timeout(1500) })
    if (response.ok) {
      const body = await response.json()
      if (body?.ok === true && body?.service === 'aharane') {
        healthy = true
        break
      }
    }
  } catch {}
  await pause(1000)
}

if (healthy) {
  await writeState({ ...state, status: 'succeeded', finishedAt: new Date().toISOString() })
  if (['manual-files', 'manual-discard'].includes(state.source)) {
    await rm('/var/lib/aharane/updates/manual-edit-state.json', { force: true }).catch(() => {})
  }
  await rm('/var/lib/aharane/deploy-lock', { recursive: true, force: true }).catch(() => {})
  process.exit(0)
}

const temporaryLink = path.join(root, '.current-rollback-' + randomUUID())
try {
  await symlink(previous, temporaryLink, 'dir')
  await rename(temporaryLink, current)
  await writeState({
    ...state,
    status: 'rolled_back',
    message: 'The new release did not pass its local health check. The previous Aharane release was restored.',
    finishedAt: new Date().toISOString(),
  })
  if (state.source === 'manual-files') {
    await rm('/var/lib/aharane/updates/manual-edit-state.json', { force: true }).catch(() => {})
  }
} catch (error) {
  await writeState({
    ...state,
    status: 'rollback_failed',
    message: String(error?.message || 'Could not restore the previous release.'),
    finishedAt: new Date().toISOString(),
  })
}
await rm('/var/lib/aharane/deploy-lock', { recursive: true, force: true }).catch(() => {})
process.exit(1)
VERIFY
chown root:root /usr/local/lib/aharane/verify-update.mjs
chmod 0644 /usr/local/lib/aharane/verify-update.mjs
install -d -o "$SERVICE_USER" -g "$SERVICE_USER" -m 0750 "$RELEASE"
cp -a "$STAGING/." "$RELEASE/"
chown -R "$SERVICE_USER:$SERVICE_USER" "$RELEASE"
chown -R "$SERVICE_USER:$SERVICE_USER" "$STATE"
chmod 0700 "$STATE" "$STATE/whatsapp-auth" "$STATE/data"

if [[ ! -f "$ENV_FILE" ]]; then
  install -o root -g "$SERVICE_USER" -m 0640 "$RELEASE/.env.example" "$ENV_FILE"
fi
if grep -q '^AHARANE_ADMIN_TOKEN=GENERATE_ON_INSTALL$' "$ENV_FILE" || ! grep -q '^AHARANE_ADMIN_TOKEN=.' "$ENV_FILE"; then
  token="$(openssl rand -hex 32)"
  if grep -q '^AHARANE_ADMIN_TOKEN=' "$ENV_FILE"; then
    sed -i "s/^AHARANE_ADMIN_TOKEN=.*/AHARANE_ADMIN_TOKEN=$token/" "$ENV_FILE"
  else
    printf '\nAHARANE_ADMIN_TOKEN=%s\n' "$token" >> "$ENV_FILE"
  fi
fi
if grep -q '^AHARANE_DATA_DIR=' "$ENV_FILE"; then
  sed -i "s|^AHARANE_DATA_DIR=.*|AHARANE_DATA_DIR=$STATE|" "$ENV_FILE"
else
  printf '\nAHARANE_DATA_DIR=%s\n' "$STATE" >> "$ENV_FILE"
fi
if ! grep -q '^AHARANE_HOST=' "$ENV_FILE"; then
  printf 'AHARANE_HOST=127.0.0.1\n' >> "$ENV_FILE"
fi
if grep -q '^AHARANE_PORT=' "$ENV_FILE"; then
  sed -i 's/^AHARANE_PORT=.*/AHARANE_PORT=8790/' "$ENV_FILE"
else
  printf 'AHARANE_PORT=8790\n' >> "$ENV_FILE"
fi
# Keep Aharane's state root, listener and port private and fixed.
sed -i 's/^AHARANE_HOST=.*/AHARANE_HOST=127.0.0.1/' "$ENV_FILE"
admin_token="$(sed -n 's/^AHARANE_ADMIN_TOKEN=//p' "$ENV_FILE" | tail -1 | tr -d '\r')"
[[ ${#admin_token} -ge 32 ]] || { echo "AHARANE_ADMIN_TOKEN must contain at least 32 characters." >&2; exit 2; }
chown root:"$SERVICE_USER" "$ENV_FILE"
chmod 0640 "$ENV_FILE"

runuser -u "$SERVICE_USER" -- npm --prefix "$RELEASE" install --omit=dev --no-audit --no-fund
printf '%s\n' "$SOURCE_SHA" > "$RELEASE/.deployed-source-ref"
chown root:"$SERVICE_USER" "$RELEASE/.deployed-source-ref"
chmod 0440 "$RELEASE/.deployed-source-ref"

SWITCHED=1
cat > "$SERVICE_FILE" <<'UNIT'
[Unit]
Description=Aharane independent WhatsApp bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=aharane
Group=aharane
WorkingDirectory=/opt/aharane/current
EnvironmentFile=/etc/aharane.env
Environment=NODE_ENV=production
ExecStart=/usr/bin/node /opt/aharane/current/src/index.js
ExecStartPost=/usr/bin/node /usr/local/lib/aharane/verify-update.mjs
Restart=on-failure
RestartSec=5
KillSignal=SIGTERM
TimeoutStopSec=20
UMask=0077
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/aharane /opt/aharane
RestrictSUIDSGID=true
LockPersonality=true

[Install]
WantedBy=multi-user.target
UNIT
chmod 0644 "$SERVICE_FILE"

next="$BASE/.current-next-$$"
ln -s "$RELEASE" "$next"
mv -Tf "$next" "$BASE/current"
SWITCHED=1
systemctl daemon-reload
systemctl enable aharane.service >/dev/null
systemctl restart aharane.service

healthy=0
for _ in $(seq 1 25); do
  if systemctl is-active --quiet aharane.service && curl -fsS --max-time 2 http://127.0.0.1:8790/healthz | grep -q '"service":"aharane"'; then
    healthy=1
    break
  fi
  sleep 1
done

if [[ "$healthy" -ne 1 ]]; then
  echo "Aharane failed its local health check." >&2
  exit 1
fi

SUCCESS=1
echo "Aharane deployment verified: $SOURCE_SHA"
echo "Aharane service is active on 127.0.0.1:8790."
echo "The existing NIGHT service and its files were not modified."
